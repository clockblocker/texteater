"""Read-only audit of retained JSON evidence; never imports seglab modules or pickle."""
import collections
import hashlib
import json
import pathlib

ROOT = pathlib.Path('/Users/annagorelova/work/textfresser-batteries/battery/dumgen/.runs/segment-in-units-lab')
OUT = pathlib.Path('/private/tmp/segment-in-units-investigation-20260930')
SEGLAB = pathlib.Path('/private/tmp/seglab')

def read(path):
    return json.loads(path.read_text())

def route(r):
    return r if r == 'Unresolved' else '/'.join([r['language'], r['family'], r['kind']])

def scored(g):
    return g['route'] != 'Unresolved' and g['route']['family'] != 'Foreign'

def evaluate(case, output):
    segs = case['input']['segments']
    ret = [(u, set(s for s in u['segments'] if segs[s]['kind'] == 'ResolvableText')) for u in output['units']]
    result = []
    for gold in case['idealOutput']['units']:
        if not scored(gold):
            result.append(('Stub', gold, [])); continue
        gs = set(gold['segments'])
        touching = [(u, ss) for u, ss in ret if ss & gs]
        if not touching: verdict = 'Missing'
        elif len(touching) != 1 or touching[0][1] != gs: verdict = 'WrongSegments'
        else: verdict = 'Match' if route(gold['route']) == route(touching[0][0]['route']) else 'WrongRoute'
        result.append((verdict, gold, [u for u, _ in touching]))
    return result

def text(case, indices=None):
    segs = case['input']['segments']
    return ''.join(s['text'] for s in segs) if indices is None else ' '.join(segs[i]['text'] for i in sorted(indices))

def score_rows(cases, rows, policy):
    totals = collections.Counter()
    shapes = collections.Counter()
    examples = []
    for row in rows:
        case = cases[row['id']]
        for rep_index, rep in enumerate(row['repetitions']):
            output = rep['outputs'][policy]
            for verdict, gold, touching in evaluate(case, output):
                totals[verdict] += 1
                if verdict in ('Stub', 'Match'): continue
                gs = set(gold['segments'])
                sets = [set(s for s in u['segments'] if case['input']['segments'][s]['kind'] == 'ResolvableText') for u in touching]
                if verdict == 'WrongRoute': shape = 'route'
                elif not touching: shape = 'missing'
                elif len(sets)>1 and all(ss <= gs for ss in sets): shape = 'split'
                elif len(sets)==1 and sets[0]>gs: shape = 'overgroup'
                else: shape = 'cross'
                shapes[f'{gold["route"]["family"]}/{shape}'] += 1
                if rep_index == 0:
                    examples.append({'id': row['id'], 'sentence': text(case), 'gold': text(case,gold['segments']), 'route': route(gold['route']), 'shape': shape, 'got': [{'text': text(case,u['segments']), 'route': route(u['route'])} for u in touching]})
    count = sum(n for k,n in totals.items() if k!='Stub')
    return {'counts': dict(totals), 'jointAccuracy': totals['Match']/count, 'membershipAccuracy': (totals['Match']+totals['WrongRoute'])/count, 'shapes': dict(shapes), 'examples': examples}

sets = {name: read(ROOT/'sets'/f'{name}.json') for name in ('dev','heldout')}
cases_by_set = {name:{c['id']:c for c in s['cases']} for name,s in sets.items()}
runs = {
  'v3': read(ROOT/'runs'/'20260929T074903--candidates2--routes-question_tests-1_gen-3--dev--all.json'),
  'tagged': read(ROOT/'runs'/'20260929T075319--candidates2--routes-question_tests-1_gen-3_render-tagged--dev--slice300.json'),
  'luna': read(ROOT/'runs'/'20260929T073850--luna--routes-state_effort-low--dev--slice300.json'),
  'pairwise': read(ROOT/'runs'/'20260929T072641--pairwise--routes-state--dev--slice300.json'),
  'oracle': read(ROOT/'runs'/'20260929T073940--oracle--routes-question_tests-1--dev--slice300.json')
}
policies = {'v3':'full@0.7+family','tagged':'full@0.7+family','luna':'luna','pairwise':'t0.8','oracle':'identity'}
report = {'metadata': {name:{k:v for k,v in s.items() if k!='cases'} for name,s in sets.items()}, 'dumpCoverage':{}}
raw_dev = None
for name in ('dev','heldout','dev-tagged','dev-noguide','dev-rules'):
    entries = read(SEGLAB/f'answers-{name}.json')
    signatures = {(e['id'],e['repetition']) for e in entries}
    stages = collections.Counter()
    unanswered = extra = 0
    for e in entries:
        for log in e['log']:
            stages[log['stage']] += 1
            unanswered += len(set(log['questions'])-set(log['answers']))
            extra += len(set(log['answers'])-set(log['questions']))
    report['dumpCoverage'][name] = {'entries':len(entries),'uniqueCaseRepetitions':len(signatures),'cases':len({e['id'] for e in entries}),'stages':dict(stages),'unanswered':unanswered,'extraAnswers':extra}
    if name == 'dev':
        raw_dev = {(e['id'],e['repetition']):{log['stage']:log for log in e['log']} for e in entries}
    del entries

cases = cases_by_set['dev']
base = score_rows(cases,runs['v3']['cases'],policies['v3'])
report['baseline'] = {k:v for k,v in base.items() if k!='examples'}
route_bins = collections.defaultdict(lambda:collections.Counter())
question_gap = collections.Counter()
for row in runs['v3']['cases']:
    case = cases[row['id']]
    resolvable = [i for i,s in enumerate(case['input']['segments']) if s['kind']=='ResolvableText']
    pid = {s:i+1 for i,s in enumerate(resolvable)}
    for rep_index,rep in enumerate(row['repetitions']):
        logs = raw_dev[(row['id'],rep_index)]
        route_answers = logs.get('route',{}).get('answers',{})
        gold_sets = [(set(g['segments']),route(g['route'])) for g in case['idealOutput']['units'] if scored(g)]
        for u in rep['outputs'][policies['v3']]['units']:
            gs = set(u['segments'])
            if not any(gs & gold for gold,_ in gold_sets): continue
            ident = 'r_'+'_'.join(str(pid[s]) for s in sorted(gs))
            answer = route_answers.get(ident)
            if not answer: continue
            confidence = answer['confidence']
            label = f'{"multi" if len(gs)>1 else "single"}/'+('0.95+' if confidence>=.95 else f'{int(confidence*10)/10:.1f}')
            route_bins[label]['predictions'] += 1
            route_bins[label]['rightMembers'] += any(gs==g for g,_ in gold_sets)
            route_bins[label]['rightMembersAndRoute'] += any(gs==g and route(u['route'])==r for g,r in gold_sets)
        for verdict,gold,touching in evaluate(case,rep['outputs'][policies['v3']]):
            if verdict!='WrongSegments' or gold['route']=='Unresolved': continue
            parts = [set(u['segments']) & set(gold['segments']) for u in touching]
            if len(parts)<2: continue
            all_questions = {k for log in logs.values() for k in log['questions']}
            linking = False
            for x in gold['segments']:
                for y in gold['segments']:
                    if x>=y or any(x in part and y in part for part in parts):continue
                    a,b=pid[x],pid[y]
                    if f'e_{a}_{b}' in all_questions or f'c_{a}_{b}' in all_questions:linking=True
                    for log in logs.values():
                        for k,q in log['questions'].items():
                            if k.startswith('s_') and int(k.rsplit('_',1)[1]) in (a,b):
                                target = b if int(k.rsplit('_',1)[1])==a else a
                                if f'p{target}' in q.get('criteria',{}): linking=True
            question_gap[f'{gold["route"]["family"]}/{"a cross-part question exists" if linking else "no direct cross-part question"}'] += 1
report['underlyingRouteConfidenceBins'] = {k:dict(v) for k,v in route_bins.items()}
report['splitQuestionCoverageDiagnostic'] = dict(question_gap)

slice_ids = read(SEGLAB/'slice300.json')
mapped = {name:{row['id']:row for row in run['cases']} for name,run in runs.items()}
same_wrong = collections.Counter()
paired_tagged = collections.Counter()
agreement_examples = []
for cid in slice_ids:
    case=cases[cid]
    ev={name:evaluate(case,mapped[name][cid]['repetitions'][0]['outputs'][policies[name]]) for name in runs}
    for i,g in enumerate(case['idealOutput']['units']):
        if not scored(g): continue
        def sig(e):return tuple(sorted((tuple(sorted(u['segments'])),route(u['route'])) for u in e[2]))
        if ev['v3'][i][0]!='Match':
            same_wrong['v3Fails']+=1
            if sig(ev['v3'][i])==sig(ev['luna'][i])==sig(ev['pairwise'][i]):
                same_wrong['threeArmsSameWrong']+=1
                agreement_examples.append({'id':cid,'sentence':text(case),'gold':text(case,g['segments']),'route':route(g['route']),'actualSignature':sig(ev['v3'][i])})
            if ev['v3'][i][0]=='WrongRoute' and ev['oracle'][i][0]!='Match':same_wrong['routeStillWrongWithGoldGroups']+=1
        for r in range(3):
            a=evaluate(case,mapped['v3'][cid]['repetitions'][r]['outputs'][policies['v3']])[i][0]=='Match'
            b=evaluate(case,mapped['tagged'][cid]['repetitions'][r]['outputs'][policies['tagged']])[i][0]=='Match'
            paired_tagged[f'{a}/{b}']+=1
report['crossArmAgreementRep0'] = dict(same_wrong)
report['listVsTaggedJointPairedUnitRepetitions'] = dict(paired_tagged)
report['agreementExamples'] = agreement_examples[:12]

rep_consensus = collections.Counter()
for row in runs['v3']['cases']:
    case=cases[row['id']]
    votes=collections.Counter()
    routes={}
    for rep in row['repetitions']:
        for u in rep['outputs'][policies['v3']]['units']:
            key=(tuple(u['segments']),route(u['route']))
            votes[key]+=1;routes[key]=u['route']
    units=[{'segments':list(key[0]),'route':routes[key]} for key,count in votes.items() if count>=2]
    covered={s for u in units for s in u['segments']}
    units += [{'segments':[s],'route':'Unresolved'} for s,seg in enumerate(case['input']['segments']) if seg['kind']=='ResolvableText' and s not in covered]
    for verdict,_,_ in evaluate(case,{'units':units}):rep_consensus[verdict]+=1
report['diagnosticOnlyThreeCallExactConsensus']={'counts':dict(rep_consensus),'productionEligible':False,'reason':'Uses three repeated inferences; user requires zero retries.'}

representative=sorted(cases,key=lambda cid:hashlib.sha256(('ownership-pilot-representative:'+cid).encode()).hexdigest())[:16]
challenge=[]
for family,shape in [('Lexeme','split'),('Lexeme','overgroup'),('Locution','split'),('Locution','overgroup'),('Saying','split'),('Locution','cross'),('Lexeme','cross'),('Locution','route')]:
    options=[e for e in base['examples'] if e['route'].split('/')[1]==family and e['shape']==shape and e['id'] not in representative+challenge]
    options.sort(key=lambda e:hashlib.sha256(('ownership-pilot-challenge:'+e['id']).encode()).hexdigest())
    added = 0
    for e in options:
        if e['id'] not in challenge:
            challenge.append(e['id'])
            added += 1
            if added == 2: break
while len(challenge)<16:
    for e in base['examples']:
        if e['id'] not in representative+challenge:
            challenge.append(e['id']);break
pilot={'set':'dev','setHash':sets['dev']['hash'],'selection':'16 source-hash representative +16 baseline-failure challenge; smoke, not representative aggregate','representative':representative,'challenge':challenge[:16],'ids':representative+challenge[:16]}
(OUT/'pilot32.json').write_text(json.dumps(pilot,indent=2)+'\n')
(OUT/'failure-examples.json').write_text(json.dumps(base['examples'],indent=2)+'\n')
(OUT/'seglab-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('agreementExamples','underlyingRouteConfidenceBins')},indent=2))
print('route confidence >=.95:',{k:v for k,v in report['underlyingRouteConfidenceBins'].items() if k.endswith('0.95+')})
print('saved',OUT/'seglab-audit.json','and pilot32.json')
