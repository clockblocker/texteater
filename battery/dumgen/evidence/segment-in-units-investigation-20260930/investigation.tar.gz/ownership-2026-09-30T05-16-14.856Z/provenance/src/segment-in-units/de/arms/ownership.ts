/**
 * Every piece chooses the first attested member of its biggest unit. Code
 * groups equal labels directly, without following pointers or joining links.
 * A second request checks each exact group and routes it in parallel.
 */
import type { Questions } from "promptsmith/typesafe";
import type { SegmentInUnitsInput } from "../../../evaluation/spec-corpus/segment-in-units.js";
import { type Answers, choice, choiceOf, noul, noulOf } from "../../lab/jev.js";
import {
	type Arm,
	type ArmContext,
	type ArmResult,
	joinRefs,
	judgeState,
	readRoutes,
	routeQuestions,
} from "../arm.js";
import { closedClassQuestion, closedClassRoute } from "../closed-class.js";
import { identityCandidates } from "../identity.js";
import { groupKey, outputOf } from "../partition.js";
import { allRoutes, routeCriteria } from "../routes.js";
import { markedText, pieceGloss, sentenceOf } from "../sentence.js";

export type OwnershipJudgment = {
	readonly piece: number;
	readonly owner?: number;
	readonly share: number;
	readonly confidence: number;
	/** Source uncertainty or a Choice exceeding the 255-option limit. */
	readonly forced: boolean;
};

export type OwnershipResult = ArmResult & {
	readonly owners: readonly OwnershipJudgment[];
	readonly support: readonly {
		readonly group: readonly number[];
		readonly probability: number;
	}[];
	/** A selected authored candidate group; later resolution may refine its cell. */
	readonly identityHints?: readonly {
		readonly sourceSegment: number;
		readonly candidateGroup: string;
		readonly share: number;
		readonly confidence: number;
	}[];
};

const ownerId = (piece: number) => `owner_${piece}`;
const supportId = (group: readonly number[]) => `support_${group.join("_")}`;
const closedId = (piece: number) => `ownership_cc_${piece}`;

/**
 * The optional source indices let the raw-text adapter preserve an uncertain
 * split as its own Unresolved unit without changing the gold harness input.
 */
export async function runOwnership(
	input: SegmentInUnitsInput,
	context: ArmContext,
	unresolvedSourceSegments: readonly number[] = [],
): Promise<OwnershipResult> {
	const sentence = sentenceOf(input);
	const { state, ref } = judgeState(sentence, context);
	const sourceUnresolved = new Set(unresolvedSourceSegments);
	const forced = new Set(
		sentence.pieces
			.filter((piece) => sourceUnresolved.has(piece.segment))
			.map((piece) => piece.id),
	);
	const questions: Questions = {};
	const candidatesByPiece = new Map<number, Set<number>>();
	for (const piece of sentence.pieces) {
		if (forced.has(piece.id)) continue;
		const candidates = sentence.pieces.filter(
			(candidate) =>
				candidate.id <= piece.id && !forced.has(candidate.id),
		);
		// Never truncate the possible owners to fit a request. The fallback
		// preserves coverage, and the final check can reject missing members.
		if (candidates.length + 1 > 255) {
			forced.add(piece.id);
			continue;
		}
		candidatesByPiece.set(
			piece.id,
			new Set(candidates.map((candidate) => candidate.id)),
		);
		questions[ownerId(piece.id)] = choice(
			`In \`sentence\`, which listed piece is the first attested member, in source order, of the biggest unit containing ${ref(piece)}? Choose that same first member for every piece of one unit, even across intervening free words. An article or auxiliary may be the first member; the label does not name the unit's grammatical Head. Choose p${piece.id} when ${ref(piece)} is itself the first member, including a unit on its own. Apply the supplied unit policy.`,
			{
				...Object.fromEntries(
					candidates.map((candidate) => [
						`p${candidate.id}`,
						`${pieceGloss(candidate)} (p${candidate.id})`,
					]),
				),
				Unresolved: "No listed first member can be defensibly selected",
			},
		);
	}
	const ownerAnswers = await context.jev.ask({
		stage: "ownership",
		state,
		questions,
		repetition: context.repetition,
		calls: context.calls,
	});
	const owners: OwnershipJudgment[] = sentence.pieces.map((piece) => {
		if (forced.has(piece.id))
			return { piece: piece.id, share: 0, confidence: 0, forced: true };
		const answer = choiceOf(ownerAnswers, ownerId(piece.id));
		const owner = /^p\d+$/u.test(answer.choice)
			? Number(answer.choice.slice(1))
			: undefined;
		return {
			piece: piece.id,
			...(owner !== undefined &&
			candidatesByPiece.get(piece.id)?.has(owner)
				? { owner }
				: {}),
			share: answer.probabilities[answer.choice] ?? 0,
			confidence: answer.confidence,
			forced: false,
		};
	});
	const byOwner = new Map<number, number[]>();
	for (const judgment of owners) {
		const label = judgment.owner ?? judgment.piece;
		const group = byOwner.get(label) ?? [];
		group.push(judgment.piece);
		byOwner.set(label, group);
	}
	const groups = [...byOwner.values()].sort(
		(left, right) => (left[0] ?? 0) - (right[0] ?? 0),
	);
	const selfOwned = (group: readonly number[]) => {
		const first = owners[(group[0] ?? 0) - 1];
		const owner = first?.owner;
		return (
			owner !== undefined &&
			group[0] === owner &&
			owners[owner - 1]?.owner === owner
		);
	};
	const known = groups.filter((group) => !group.some((id) => forced.has(id)));
	const routeGuide = context.options.routeguide;
	const finalContext =
		routeGuide === undefined
			? context
			: {
					...context,
					options: { ...context.options, guide: routeGuide },
				};
	const finalState = judgeState(sentence, finalContext);
	// Authored candidates describe the recovered word, while every question
	// still names the source letters and their original piece coordinate.
	const identitySentence = {
		...sentence,
		pieces: sentence.pieces.map((piece) => ({
			...piece,
			text: piece.surface,
		})),
	};
	const sourceRef = (piece: (typeof sentence.pieces)[number]) =>
		finalState.ref(sentence.pieces[piece.id - 1] ?? piece);
	const finalQuestions = routeQuestions(
		identitySentence,
		known,
		sourceRef,
		context,
	);
	const closed = context.options.closed === "1";
	for (const group of known) {
		const routeId = `r_${group.join("_")}`;
		if (group.length === 1 && context.options.singletonRoutes === "all")
			finalQuestions[routeId] = choice(
				`In \`sentence\`, the attested member ${joinRefs(sentence, finalState.ref, group)} forms one biggest unit. Which route does that whole unit take? A single member may attest a Partial Locution or Saying when other fixed material is genuinely missing, shared, or replaced; an abbreviation may also stand for a whole Locution. Judge the whole unit in context, including that possibility.`,
				routeCriteria(allRoutes, context.options.routes !== "state"),
			);
		const routeQuestion = finalQuestions[routeId];
		if (
			routeQuestion?.type !== "choice" ||
			routeQuestion.instructions === undefined
		)
			throw Error(`Missing route question ${routeId}`);
		finalQuestions[routeId] = choice(routeQuestion.instructions, {
			...routeQuestion.criteria,
			Unresolved:
				"No route is defensible for this unit: unintelligible text, a nonce word with no plausible lexical analysis, or material broken off without a recoverable whole",
		});
		finalQuestions[supportId(group)] = noul(
			`In \`sentence\`, are all and only the marked pieces in \`groups.g${group.join("_")}\` the attested members of one biggest unit? Every member present in this sentence must be marked, and every marked piece must belong to that unit. A fragment missing present members, extra free words, or several separate units is false. Intervening free words need not be marked. Material genuinely elided, shared with another unit, or replaced in a licensed Modification does not make its remaining attested members incomplete.`,
			{
				true: "Exactly one biggest unit's complete attested membership",
				false: "Missing present members, extra members, several units, or no defensible unit",
			},
		);
		const [only] = group;
		if (closed && group.length === 1 && only !== undefined) {
			const piece = sentence.pieces[only - 1];
			const question = piece && closedClassQuestion(piece);
			if (piece && question)
				finalQuestions[closedId(only)] = choice(
					question.instructions(finalState.ref(piece)),
					{ ...question.criteria },
				);
		}
	}
	const finalAnswers: Answers = await context.jev.ask({
		stage: "ownership-final",
		state: {
			...finalState.state,
			groups: Object.fromEntries(
				known.map((group) => [
					`g${group.join("_")}`,
					markedText(sentence, group),
				]),
			),
		},
		questions: finalQuestions,
		repetition: context.repetition,
		calls: context.calls,
	});
	const routes = readRoutes(identitySentence, known, finalAnswers).identity;
	const identityHints = known.flatMap((group) => {
		const [only] = group;
		if (group.length !== 1 || only === undefined) return [];
		const piece = sentence.pieces[only - 1];
		const answer = finalAnswers[`i_${only}`];
		if (
			!piece ||
			answer?.type !== "choice" ||
			!/^c\d+$/u.test(answer.choice)
		)
			return [];
		const candidate = identityCandidates(piece.surface)[
			Number(answer.choice.slice(1))
		];
		return candidate
			? [
					{
						sourceSegment: piece.segment,
						candidateGroup: candidate.key,
						share: answer.probabilities[answer.choice] ?? 0,
						confidence: answer.confidence,
					},
				]
			: [];
	});
	const support = known.map((group) => ({
		group,
		probability: noulOf(finalAnswers, supportId(group)),
	}));
	const supportByGroup = new Map(
		support.map((judgment) => [
			groupKey(judgment.group),
			judgment.probability,
		]),
	);
	const policies = [
		{ name: "raw", self: false, support: 0, route: 0 },
		{ name: "self", self: true, support: 0, route: 0 },
		...[0.5, 0.7, 0.8].map((floor) => ({
			name: `support@${floor}`,
			self: true,
			support: floor,
			route: 0,
		})),
		{ name: "support@0.7+route@0.5", self: true, support: 0.7, route: 0.5 },
		{ name: "support@0.8+route@0.8", self: true, support: 0.8, route: 0.8 },
	];
	const outputs: ArmResult["outputs"] = Object.fromEntries(
		policies.flatMap((policy) =>
			(closed ? [false, true] : [false]).map((withClosed) => [
				`${policy.name}${withClosed ? "+closed" : ""}`,
				outputOf(sentence, groups, (group) => {
					const key = groupKey(group);
					const judgment = routes.get(key);
					if (
						group.some((id) => forced.has(id)) ||
						(policy.self && !selfOwned(group)) ||
						(supportByGroup.get(key) ?? 0) < policy.support ||
						!judgment
					)
						return "Unresolved";
					const [only] = group;
					const piece =
						only === undefined
							? undefined
							: sentence.pieces[only - 1];
					const answer =
						only === undefined
							? undefined
							: finalAnswers[closedId(only)];
					const chosenClosed =
						withClosed && group.length === 1 && piece
							? closedClassRoute(
									piece,
									answer?.type === "choice"
										? answer.choice
										: undefined,
								)
							: undefined;
					const confidence = chosenClosed
						? answer?.type === "choice"
							? answer.confidence
							: 1
						: judgment.confidence;
					return confidence < policy.route
						? "Unresolved"
						: (chosenClosed ?? judgment.choice);
				}),
			]),
		),
	);
	return {
		primary: `support@0.7${closed ? "+closed" : ""}`,
		outputs,
		routes: [...routes.values()],
		owners,
		support,
		...(identityHints.length > 0 ? { identityHints } : {}),
	};
}

export const ownershipArm = {
	id: "ownership",
	summary:
		"Canonical owner Choice, direct grouping, then exact membership and route judgments",
	run: runOwnership,
} satisfies Arm;
