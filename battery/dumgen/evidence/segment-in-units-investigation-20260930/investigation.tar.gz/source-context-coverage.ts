/** Offline supplied-plan coverage only. It does not choose answers or run inference. */
import { createHash } from "node:crypto";
import { readFile, writeFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { prepareGermanSource as revised } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/source.ts";

const repository = "/Users/annagorelova/work/textfresser-batteries";
const directory = "/private/tmp/segment-in-units-investigation-20260930";
const currentPath = `${repository}/battery/dumgen/src/segment-in-units/de/source.ts`;
const previousPath = `${directory}/envelopes-2026-09-30T05-25-47.499Z/provenance/src/segment-in-units/de/source.ts`;
const oldBody = await readFile(previousPath, "utf8");
const oldExecutable = oldBody.replace(/from "([.][^"]+)"/gu, (_, relative) => `from "${resolve(dirname(currentPath), relative).replace(/\.js$/u, ".ts")}"`);
const oldExecutablePath = `${directory}/source-context-coverage-old.ts`;
await writeFile(oldExecutablePath, oldExecutable);
const { prepareGermanSource: previous } = await import(oldExecutablePath);
const sets = await Promise.all(["dev", "heldout"].map(async (name) => JSON.parse(await readFile(`${repository}/battery/dumgen/.runs/segment-in-units-lab/sets/${name}.json`, "utf8"))));
const coverage = (cases, prepare) => {
	const totals = { sentences: cases.length, contextualSentences: 0, questions: 0, questionOptions: 0,
		suppliedPlans: 0, allSourceBoundaryAndKindCandidatesPresent: 0, allStrictSurfaceCandidatesPresent: 0, allAnnotatedSurfaceCandidatesPresent: 0 };
	const rows = [];
	for (const entry of cases) {
		let offset = 0;
		const gold = entry.input.segments.map((segment) => { const result = { ...segment, start: offset, end: offset + segment.text.length }; offset = result.end; return result; });
		const prepared = prepare(entry.input.segments.map(({text}) => text).join(""));
		const questions = Object.keys(prepared.questions).length;
		totals.contextualSentences += Number(questions > 0);
		totals.questions += questions;
		totals.questionOptions += Object.values(prepared.questions).reduce((sum, question) => sum + Object.keys(question.criteria).length, 0);
		totals.suppliedPlans += prepared.runs.reduce((sum, run) => sum + run.plans.length, 0);
		const present = (recovery) => prepared.runs.every((run) => {
			const expected = gold.filter((segment) => segment.start >= run.start && segment.end <= run.end);
			if (expected[0]?.start !== run.start || expected.at(-1)?.end !== run.end) return false;
			return run.plans.some((plan) => plan.segments.length === expected.length && plan.segments.every((actual, index) => {
				const expectedSegment = expected[index];
				return actual.kind === expectedSegment.kind && actual.text === expectedSegment.text &&
					(recovery === "none" || (recovery === "annotated" && expectedSegment.surface === undefined) ||
					(actual.surface ?? actual.text) === (expectedSegment.surface ?? expectedSegment.text));
			}));
		});
		const source = present("none"), strict = present("strict"), annotated = present("annotated");
		totals.allSourceBoundaryAndKindCandidatesPresent += Number(source);
		totals.allStrictSurfaceCandidatesPresent += Number(strict);
		totals.allAnnotatedSurfaceCandidatesPresent += Number(annotated);
		rows.push({ id: entry.id, questions, source, strict, annotated, questionedRuns: Object.keys(prepared.questions).map((id) => {
			const run = prepared.runs[Number(id.slice(7))];
			return { text: run.text, plans: run.plans.map(({ key }) => key) };
		}) });
	}
	return { totals, rows };
};
const cases = sets.flatMap((set) => set.cases);
const old = coverage(cases, previous), updated = coverage(cases, revised);
const addedQuestionsByPlan = {};
for (const entry of cases) {
	const text = entry.input.segments.map(({text}) => text).join("");
	const oldPrepared = previous(text), newPrepared = revised(text);
	for (const id of Object.keys(newPrepared.questions)) {
		if (id in oldPrepared.questions) continue;
		const run = newPrepared.runs[Number(id.slice(7))];
		const first = run.plans[0]?.key.replace(/\d+$/u, "") ?? "Unknown";
		addedQuestionsByPlan[first] = (addedQuestionsByPlan[first] ?? 0) + 1;
	}
}
const audit = { kind: "Offline authored candidate presence; not segmentation accuracy or inference quality", createdAt: new Date().toISOString(),
	setHashes: Object.fromEntries(sets.map((set) => [set.name, set.hash])), previousSourceHash: createHash("sha256").update(oldBody).digest("hex"),
	revisedSourceHash: createHash("sha256").update(await readFile(currentPath)).digest("hex"),
	assumptions: ["Inputs are concatenated spelling from the frozen source records only; annotations are used only to check supplied candidate presence",
		"No answer selected, no oracle output assembled, no inference calls", "Previous executable body is the immutable pilot source snapshot with its imports redirected to unchanged current authored tables/helpers",
		"Candidate presence does not prove Jev will select that plan; an intact option can match an unannotated gold surface while omitting a semantically required recovery",
		"Every source run must have an exact boundary/kind option for the all-source candidate count; failure is retained"],
	previous: old.totals, revised: updated.totals, addedQuestionsByPlan, revisedRows: updated.rows };
const outputPath = `${directory}/source-context-candidate-coverage.json`;
await writeFile(outputPath, `${JSON.stringify(audit, null, 2)}\n`);
console.log(JSON.stringify({outputPath, previous:old.totals,revised:updated.totals,addedQuestionsByPlan}, null, 2));
