/** Synthetic offline size probe; its cache is isolated from real inference. */
import { readFile, writeFile } from "node:fs/promises";
import { runEnvelopes } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/arms/envelopes.ts";
import { segmentGermanSource } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/source.ts";
import { PilotJev } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/pilot-jev.ts";

const root = "/private/tmp/segment-in-units-investigation-20260930";
const manifest = JSON.parse(await readFile(`${root}/pilot32.json`, "utf8"));
const gold = JSON.parse(await readFile("/Users/annagorelova/work/textfresser-batteries/battery/dumgen/.runs/segment-in-units-lab/sets/dev.json", "utf8"));
const byId = new Map(gold.cases.map((row) => [row.id, row]));
const rows = [];
for (const scenario of ["singleton-envelopes", "all-long-envelopes"]) {
	for (const mode of ["gold", "source"]) {
		for (const id of manifest.ids) {
			const row = byId.get(id);
			const calls = [], requests = [];
			const fakeExecutor = async (request) => {
				const answers = {};
				for (const [key, question] of Object.entries(request.questions)) {
					if (question.type === "noul") answers[key] = { type: "noul", noul: 1 };
					else if (question.type === "choice") {
						const options = Object.keys(question.criteria);
						const endpoints = options.filter((option) => /^p\d+$/.test(option));
						const selected = key.startsWith("envelope_last_")
							? (scenario === "all-long-envelopes" ? endpoints.at(-1) : endpoints[0])
							: key.startsWith("envelope_member_")
								? options.find((option) => option.startsWith("s_"))
								: options.includes("Unresolved") ? "Unresolved" : options[0];
						answers[key] = { type: "choice", choice: selected, confidence: 1,
							probabilities: Object.fromEntries(options.map((option) => [option, Number(option === selected)])) };
					}
				}
				requests.push({ stateBytes: Buffer.byteLength(JSON.stringify(request.state), "utf8"),
					requestBytes: Buffer.byteLength(JSON.stringify(request), "utf8"),
					questions: Object.keys(request.questions).length,
					maxStatePlusQuestionBytes: Math.max(0, ...Object.values(request.questions).map((question) => Buffer.byteLength(JSON.stringify(request.state), "utf8") + Buffer.byteLength(JSON.stringify(question), "utf8"))) });
				return { model: "jev-1.13.0", answers, usage: { input_tokens: 0, output_tokens: 0 } };
			};
			const jev = new PilotJev({ model: "jev-1.13.0", maxRetries: 0, concurrency: 2,
				cacheDirectory: `${root}/preflight-cache-${scenario}`, executor: fakeExecutor });
			let error, result;
			try {
				const source = mode === "source"
					? await segmentGermanSource(row.input.segments.map(({text}) => text).join(""), { jev, repetition: 0, calls })
					: { input: row.input, unresolved: [] };
				result = await runEnvelopes(source.input, { jev, repetition: 0, calls,
					options: { routes: "question", tests: "1", singletonRoutes: "all", closed: "1" } }, source.unresolved);
			} catch (caught) { error = String(caught); }
			rows.push({ id, mode, scenario, requests, error, diagnostics: result?.diagnostics });
		}
	}
}
const report = { synthetic: true, providerCalls: 0,
	notes: ["Each singleton scenario creates no multiword envelope. The long scenario conditionally selects every start and the sentence's last member, then each word chooses itself; it is a conservative dense-envelope bound, not measured Jev behavior.",
	"Only generated request sizes and guard behavior are meaningful. Synthetic answers, zero usage and cache wall times are not quality, cost or latency evidence.",
	"Framing allowance is 4096 bytes; production checks actual generated stages again before every request without truncating any options."],
	rows, errors: rows.filter(({error}) => error).map(({id,mode,scenario,error}) => ({id,mode,scenario,error})),
	maxRequestPlusFraming: Math.max(0, ...rows.flatMap(({requests}) => requests.map(({requestBytes}) => requestBytes + 4096))),
	maxStateQuestionPlusFraming: Math.max(0, ...rows.flatMap(({requests}) => requests.map(({maxStatePlusQuestionBytes}) => maxStatePlusQuestionBytes + 4096))) };
await writeFile(`${root}/envelope-preflight.json`, `${JSON.stringify(report, null, 2)}\n`);
console.log(JSON.stringify({ rows: rows.length, errors: report.errors, maxRequestPlusFraming: report.maxRequestPlusFraming,
	maxStateQuestionPlusFraming: report.maxStateQuestionPlusFraming, providerCalls: 0 }));
