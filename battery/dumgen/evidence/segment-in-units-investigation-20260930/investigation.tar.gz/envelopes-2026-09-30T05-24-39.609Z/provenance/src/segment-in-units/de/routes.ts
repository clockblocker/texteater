/**
 * The German routes a `segment.inUnits` unit can take, as option keys
 * (`Lexeme/VERB`) with the short descriptions the judge reads. AUX and PUNCT
 * are left out: an auxiliary always joins the verb it serves, and
 * punctuation is never scored.
 */
import type { Route } from "../../evaluation/spec-corpus/segment-in-units.js";

export const lexemeKinds = [
	"ADJ",
	"ADP",
	"ADV",
	"CCONJ",
	"DET",
	"INTJ",
	"NOUN",
	"NUM",
	"PART",
	"PRON",
	"PROPN",
	"SCONJ",
	"SYM",
	"VERB",
] as const;

export const locutionKinds = [
	"ADJ",
	"ADP",
	"ADV",
	"CCONJ",
	"DET",
	"INTJ",
	"NOUN",
	"NUM",
	"PRON",
	"SCONJ",
	"VERB",
] as const;

export type RouteKey = string;

export const routeDescriptions: Readonly<Record<RouteKey, string>> = {
	"Lexeme/ADJ":
		"Adjective, also comparative or used adverbially (singt laut), and every participle outside a perfect or passive (die gebratenen Zwiebeln, Die Tür ist geschlossen)",
	"Lexeme/ADP":
		"Preposition or postposition that no word governs (im Keller)",
	"Lexeme/ADV":
		"Adverb, including pronominal adverbs (darauf, davon), a split adverb (Da … von, Wo … hin) and interrogative or relative wo, wann, wie, warum",
	"Lexeme/CCONJ": "Coordinating conjunction (und, oder, aber, denn, sondern)",
	"Lexeme/DET":
		"Determiner that modifies a noun and is not der/die/das/ein (mein, dieser, kein, jeder, welcher)",
	"Lexeme/INTJ":
		"Interjection or one-word response or formula (ach, ja, nein, danke)",
	"Lexeme/NOUN":
		"Common noun, with the article that opens its phrase (der Hund, ein Haus, m in im Wald); substantivized adjectives and infinitives included",
	"Lexeme/NUM": "Numeral (drei, 12)",
	"Lexeme/PART":
		"Particle: nicht, zu before an infinitive, am before a superlative when not joined, answer particles",
	"Lexeme/PRON":
		"Pronoun standing for a noun phrase: personal, reflexive object, relative, demonstrative, interrogative, indefinite (man, etwas)",
	"Lexeme/PROPN":
		"Proper name, with the article that opens its phrase (die Schweiz, der Rhein)",
	"Lexeme/SCONJ": "Subordinating conjunction (dass, weil, ob, als, wenn)",
	"Lexeme/SYM": "Symbol such as %, €, §, +",
	"Lexeme/VERB":
		"One verb with its separable particle, required reflexive, auxiliaries, expletive es and governed preposition; modals and copulas included",
	"Locution/ADJ": "Fixed multiword expression acting as an adjective",
	"Locution/ADP":
		"Fixed multiword preposition or circumposition (um … willen)",
	"Locution/ADV":
		"Fixed multiword adverbial (zum Teil, auf keinen Fall, so oder so, ganz und gar)",
	"Locution/CCONJ":
		"Fixed correlative conjunction (entweder … oder, weder … noch, nicht nur … sondern auch)",
	"Locution/DET": "Fixed multiword determiner (was für ein)",
	"Locution/INTJ":
		"Fixed routine formula or exclamation (guten Morgen, tut mir leid, gern geschehen)",
	"Locution/NOUN": "Fixed multiword noun expression (weißer Rabe)",
	"Locution/NUM": "Fixed multiword numeral expression",
	"Locution/PRON": "Fixed multiword pronoun (was für einer)",
	"Locution/SCONJ":
		"Fixed multiword subordinator or correlator (um … zu, je … desto, so dass)",
	"Locution/VERB":
		"Idiom or collocation acting as a verb (den Faden verlieren, zur Verfügung stellen, Angst haben)",
	"Saying/Saying":
		"A complete proverb or quotation used as a saying (Morgenstund hat Gold im Mund)",
	"Foreign/Foreign":
		"A word or fixed phrase of another language that shows no German grammar here (very good, by the way)",
};

export const singletonRoutes: readonly RouteKey[] = [
	...lexemeKinds.map((kind) => `Lexeme/${kind}`),
	"Foreign/Foreign",
];

export const allRoutes: readonly RouteKey[] = [
	...lexemeKinds.map((kind) => `Lexeme/${kind}`),
	...locutionKinds.map((kind) => `Locution/${kind}`),
	"Saying/Saying",
	"Foreign/Foreign",
];

export function routeOf(key: RouteKey): Route | "Unresolved" {
	if (key === "Unresolved") return "Unresolved";
	const [family, kind] = key.split("/");
	if (!family || !kind) throw Error(`Not a route key: ${key}`);
	return { language: "de", family, kind };
}

export function keyOf(route: Route | "Unresolved"): RouteKey {
	return route === "Unresolved" ? route : `${route.family}/${route.kind}`;
}

/** Choice criteria over routes: described in the option, or named only. */
export function routeCriteria(
	keys: readonly RouteKey[],
	described: boolean,
): Record<string, string | null> {
	return Object.fromEntries(
		keys.map((key) => [
			key,
			described ? (routeDescriptions[key] ?? null) : null,
		]),
	);
}
