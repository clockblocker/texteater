import type { EvaluationExecutor } from "/Users/annagorelova/work/textfresser-batteries/battery/promptsmith/src/evaluation.ts";

/** A normalization requires separately verified evidence; this smoke configures none. */
export type VerifiedTierNormalization = {
	readonly requestedTier: string;
	readonly returnedTier: string;
	readonly verified: true;
	readonly verificationSource: string;
	readonly verifiedAt: string;
};

export class ReturnedTierMismatch extends Error {
	readonly returnedMetadata: unknown;
	constructor(requested: unknown, returned: unknown, metadata: unknown) {
		super(`Requested text tier ${String(requested)}, returned ${String(returned)}; text dispatch stopped`);
		this.name = "ReturnedTierMismatch";
		this.returnedMetadata = metadata;
	}
}

/** Permanently stops this executor after a failure or an unverified tier mismatch. */
export function createTierGuardedExecutor(
	execute: EvaluationExecutor,
	verifiedNormalizations: readonly VerifiedTierNormalization[] = [],
): EvaluationExecutor {
	for (const normalization of verifiedNormalizations)
		if (
			normalization.verified !== true ||
			!normalization.verificationSource.trim() ||
			!Number.isFinite(Date.parse(normalization.verifiedAt))
		)
			throw Error("A tier normalization requires explicit verified evidence");
	const normalizations = [...verifiedNormalizations];
	let stopped = false;
	return async (request) => {
		if (stopped) throw Error("Text provider dispatch has already stopped");
		try {
			const response = await execute(request);
			const metadata = response.metadata;
			const returnedTier =
				metadata && typeof metadata === "object" && "serviceTier" in metadata
					? metadata.serviceTier
					: undefined;
			const requestedTier = request.configuration.settings.service_tier;
			const normalized = normalizations.some(
				(mapping) => mapping.requestedTier === requestedTier && mapping.returnedTier === returnedTier,
			);
			if (returnedTier !== requestedTier && !normalized)
				throw new ReturnedTierMismatch(requestedTier, returnedTier, metadata);
			return response;
		} catch (error) {
			stopped = true;
			throw error;
		}
	};
}
