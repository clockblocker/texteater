import { expect, test } from "bun:test";
import { writeFile } from "node:fs/promises";
import { join } from "node:path";
import { createTierGuardedExecutor, ReturnedTierMismatch } from "./tier-guard.ts";

test("an unverified priority response to fast permanently blocks a second provider dispatch", async () => {
	let providerDispatches = 0;
	const execute = createTierGuardedExecutor(async () => {
		providerDispatches++;
		return {
			output: { proposals: [] },
			metadata: { model: "gpt-5.6-luna", serviceTier: "priority", usage: { input_tokens: 1, output_tokens: 1 } },
		};
	}, []);
	const request = {
		systemPrompt: "mock only",
		input: {},
		outputSchema: {},
		configuration: { model: "gpt-5.6-luna", settings: { service_tier: "fast", max_output_tokens: 4096 } },
	};
	let firstError: unknown;
	try { await execute(request); } catch (error) { firstError = error; }
	expect(firstError).toBeInstanceOf(ReturnedTierMismatch);
	expect(firstError instanceof Error ? firstError.message : "").toContain("returned priority");
	await expect(execute(request)).rejects.toThrow("already stopped");
	expect(providerDispatches).toBe(1);
	await writeFile(join(import.meta.dir, "test-result.json"), JSON.stringify({
		mockOnly: true,
		liveRequests: 0,
		configuredTier: "fast",
		mockReturnedTier: "priority",
		verifiedNormalizations: [],
		executorInvocations: 2,
		providerDispatches,
		secondDispatchBlocked: true,
		passed: true,
	}, null, 2));
});
