import { createTierGuardedExecutor, ReturnedTierMismatch } from "./tier-guard.ts";
import { execFileSync } from "node:child_process";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import { parseArgs } from "node:util";
import { createOpenAIExecutor } from "/Users/annagorelova/work/textfresser-batteries/battery/promptsmith/src/openai.ts";
import { createTypeSafeExecutor } from "/Users/annagorelova/work/textfresser-batteries/battery/promptsmith/src/typesafe.ts";
import { proposalLimits, runProposals } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/arms/proposals.ts";
import { ruleStatements, unitGuide } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/guide.ts";
import { evaluateSourceAndUnits, sourceSpans } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/source-evaluation.ts";
import { loadSet } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/corpus.ts";
import { hashOf } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/jev.ts";
import { Luna, lunaConfiguration } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/luna.ts";
import { modeledLatency } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/metrics.ts";
import { PilotBudget } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/pilot-budget.ts";
import { PilotJev } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/pilot-jev.ts";
import { loadLabRun } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/lab/run.ts";

const root = "/private/tmp/segment-in-units-investigation-20260930";
const packageRoot = "/Users/annagorelova/work/textfresser-batteries/battery/dumgen";
const labRoot = join(packageRoot, ".runs/segment-in-units-lab");
const priorPath = join(root, "envelopes-2026-09-30T05-25-47.499Z/run.json");
const ownerPath = join(root, "ownership-2026-09-30T05-16-23.759Z/run.json");
const { values } = parseArgs({ args: Bun.argv.slice(2), options: { live: { type: "boolean", default: false }, output: { type: "string" } } });
const manifest = JSON.parse(await readFile(join(root, "pilot32.json"), "utf8"));
const set = await loadSet(labRoot, "dev");
if (set.hash !== manifest.setHash || manifest.set !== "dev") throw Error("Frozen source manifest changed");
const ids = manifest.representative.slice(0, 4);
if (ids.length !== 4 || new Set(ids).size !== 4) throw Error("Exactly four unique representative IDs required");
const cases = ids.map((id) => {
	const item = set.cases.find((item) => item.id === id);
	if (!item) throw Error(`Missing frozen case ${id}`);
	return item;
});
const prior = JSON.parse(await readFile(priorPath, "utf8"));
await readFile(join(dirname(priorPath), "summary.json"), "utf8");
if (prior.configuration.arm !== "envelopes" || prior.budget.pendingReservedUsd !== 0 || prior.budget.capUsd !== 1) throw Error("A completed envelope run with settled $1 budget is required");
const budget = new PilotBudget(1, prior.budget);
const runId = `hybrid-smoke-${new Date().toISOString().replaceAll(":", "-")}`;
const outputDirectory = values.output ?? join(root, runId);
if (values.live) {
	try { await readFile(join(outputDirectory, "run.json")); throw Error("Refuse to replay an existing live smoke run"); }
	catch (error) { if (error.code !== "ENOENT") throw error; }
}
await mkdir(outputDirectory, { recursive: true });
const sourcePaths = execFileSync("rg", ["--files", "src/segment-in-units", "src/evaluation/spec-corpus/segment-in-units.ts"], { cwd: packageRoot, encoding: "utf8" }).trim().split("\n").sort();
const sourceHashes = {};
for (const path of sourcePaths) {
	const contents = await readFile(join(packageRoot, path));
	sourceHashes[path] = hashOf(contents.toString("utf8"));
	const copy = join(outputDirectory, "provenance", path);
	await mkdir(dirname(copy), { recursive: true });
	await writeFile(copy, contents);
}
sourceHashes["temporary-hybrid-smoke.ts"] = hashOf(await readFile(import.meta.path, "utf8"));
await writeFile(join(outputDirectory, "provenance/temporary-hybrid-smoke.ts"), await readFile(import.meta.path));
const authoritativeRules = ruleStatements();
await writeFile(join(outputDirectory, "provenance/authoritative-german-rules.json"), JSON.stringify(authoritativeRules, null, 2));
await writeFile(join(outputDirectory, "provenance/unit-guide.json"), JSON.stringify(unitGuide, null, 2));
for (const path of ["src/german-rules.ts", "src/rules.ts", "src/index.ts"]) {
	const content = await readFile(join(packageRoot, "../dumspec", path));
	sourceHashes[`dumspec/${path}`] = hashOf(content.toString("utf8"));
	const copy = join(outputDirectory, "provenance/dumspec", path);
	await mkdir(dirname(copy), { recursive: true });
	await writeFile(copy, content);
}
const options = { routes: "question", tests: "1", singletonRoutes: "all", closed: "1" };
const configuration = {
	runId, ids, repetitions: 3, mode: "gold", maximumFreshTextCalls: 12,
	text: { ...lunaConfiguration, maxOutputTokens: proposalLimits.outputTokens, timeoutMs: proposalLimits.timeoutMs, maxRetries: 0, costUsd: null, priceStatus: "unknown; separate from Jev $1 cap" },
	jev: { model: "jev-1.13.0", maxRetries: 0, capUsd: 1, priorPath, priorBudget: prior.budget },
	limits: proposalLimits, options, setHash: set.hash, setGitHead: set.gitHead,
	gitHead: execFileSync("git", ["rev-parse", "HEAD"], { cwd: packageRoot, encoding: "utf8" }).trim(),
	sourceHashes, sourceHash: hashOf(sourceHashes), goldInputHash: hashOf(cases.map(({ id, input, idealOutput }) => ({ id, input, idealOutput }))),
	authoritativeRulesHash: hashOf(authoritativeRules), unitGuideHash: hashOf(unitGuide),
	selection: "First four manifest representative IDs, three independent repetitions. Tiny smoke only; no general accuracy claim.",
	tierGuard: "Stop returned tier mismatches unless a separately verified normalization is explicitly configured; no normalization is configured.",
	stopPolicy: "Stop remaining text dispatch after any provider failure or unverified returned tier mismatch; record remaining scheduled rows as not run. No retry, model alternative or semantic sweep.",
};
await writeFile(join(outputDirectory, "configuration.json"), JSON.stringify({ ...configuration, configurationHash: hashOf(configuration) }, null, 2));
await writeFile(join(outputDirectory, "gold.json"), JSON.stringify(cases, null, 2));

const owner = JSON.parse(await readFile(ownerPath, "utf8"));
const baseline = await loadLabRun(labRoot, "20260929T074903--candidates2--routes-question_tests-1_gen-3--dev--all");
if (baseline.setHash !== set.hash) throw Error("Baseline gold mismatch");
const references = {
	baseline: { model: baseline.model, policy: "full@0.7+family", refetched: false, rows: baseline.cases.filter((row) => ids.includes(row.id)).map((row) => ({ id: row.id, repetitions: row.repetitions.slice(0, 3).map((rep) => ({ ...rep, result: { primary: "full@0.7+family", outputs: rep.outputs } })) })) },
	ownership: { path: ownerPath, rows: owner.rows.filter((row) => row.mode === "gold" && ids.includes(row.id)) },
	envelopes: { path: priorPath, rows: prior.rows.filter((row) => row.mode === "gold" && ids.includes(row.id)) },
};
await writeFile(join(outputDirectory, "references.json"), JSON.stringify(references));
console.log(JSON.stringify({ outputDirectory, execution: values.live ? "authorized live smoke" : "prepared only", ids, sourceHash: configuration.sourceHash, limits: proposalLimits, textCostUsd: null, priorJevBudget: budget.snapshot }));
if (!values.live) process.exit(0);

let freshTextCalls = 0, freshJevCalls = 0, textStopped = false;
const exchanges = [];
let rawJev;
const verifiedTierNormalizations = []; // No verified normalization is configured.
const textExecutor = createTierGuardedExecutor(createOpenAIExecutor(), verifiedTierNormalizations);
const recordText = async (request) => {
	if (textStopped || freshTextCalls >= 12) throw Error("Fresh text dispatch stopped or twelve-call cap reached");
	if (request.configuration.model !== "gpt-5.6-luna" || request.configuration.settings.service_tier !== "fast" || request.configuration.settings.max_output_tokens !== 4096 || !request.signal) throw Error("Text request configuration violates reviewed bounds");
	const ordinal = ++freshTextCalls;
	const payload = { ...request, signal: { timeoutMs: proposalLimits.timeoutMs } };
	const started = performance.now();
	await mkdir(join(outputDirectory, "requests"), { recursive: true });
	await writeFile(join(outputDirectory, "requests", `luna-${ordinal}.json`), JSON.stringify({ payload, payloadHash: hashOf(payload), maxRetries: 0 }));
	try {
		const response = await textExecutor(request);
		const metadata = response.metadata ?? {};
		const exchange = { ordinal, configuredModel: request.configuration.model, requestedTier: request.configuration.settings.service_tier, actualModel: metadata.model ?? null, actualTier: metadata.serviceTier ?? null, modelAliasVariation: metadata.model !== request.configuration.model, usage: metadata.usage ?? null, latencyMs: performance.now() - started, responseId: metadata.responseId ?? null, requestId: metadata.requestId ?? null, output: response.output, costUsd: null };
		exchanges.push(exchange);
		await writeFile(join(outputDirectory, "requests", `luna-${ordinal}-response.json`), JSON.stringify(exchange));
		if (!metadata.model || !metadata.serviceTier) {
			textStopped = true;
			throw Error("Missing resolved text model/tier metadata; stop text dispatch");
		}
		return response;
	} catch (error) {
		textStopped = true;
		const failure = { ordinal, error: error instanceof Error ? error.message : String(error), latencyMs: performance.now() - started, billedUsage: "unknown", costUsd: null, returnedMetadata: error instanceof ReturnedTierMismatch ? error.returnedMetadata : undefined };
		exchanges.push(failure);
		await writeFile(join(outputDirectory, "requests", `luna-${ordinal}-failure.json`), JSON.stringify(failure));
		throw error;
	}
};
const recordJev = async (request, requestOptions) => {
	const settle = budget.reserve();
	const ordinal = ++freshJevCalls;
	await mkdir(join(outputDirectory, "requests"), { recursive: true });
	await writeFile(join(outputDirectory, "requests", `jev-${ordinal}.json`), JSON.stringify({ request, maxRetries: 0 }));
	rawJev ??= createTypeSafeExecutor({ retry: { maxRetries: 0 } });
	let response;
	try { response = await rawJev(request, { ...requestOptions, retry: { maxRetries: 0 } }); }
	catch (error) { settle(); throw error; }
	settle(response.usage.input_tokens);
	await writeFile(join(outputDirectory, "requests", `jev-${ordinal}-response.json`), JSON.stringify({ model: response.model, usage: response.usage, answers: response.answers }));
	if (response.model !== "jev-1.13.0") throw Error(`Unexpected Jev model ${response.model}`);
	return response;
};
const cacheDirectory = join(outputDirectory, "cache");
const luna = new Luna({ cacheDirectory, concurrency: 1, executor: recordText });
const jev = new PilotJev({ cacheDirectory, model: "jev-1.13.0", maxRetries: 0, concurrency: 1, executor: recordJev });
const rows = [];
for (const labCase of cases) {
	const row = { id: labCase.id, repetitions: [] };
	rows.push(row);
	for (let repetition = 0; repetition < 3; repetition++) {
		const calls = [];
		const started = performance.now();
		if (textStopped) row.repetitions.push({ calls, wallMs: 0, notRun: true, error: "Not run after text provider failure" });
		else {
			try { row.repetitions.push({ result: await runProposals(labCase.input, { jev, luna, repetition, calls, options }, []), calls, wallMs: performance.now() - started }); }
			catch (error) { row.repetitions.push({ calls, wallMs: performance.now() - started, error: error instanceof Error ? error.message : String(error), serviceFailure: true }); }
		}
		await writeFile(join(outputDirectory, "run.json"), JSON.stringify({ configuration, budget: budget.snapshot, textCostUsd: null, freshTextCalls, freshJevCalls, exchanges, rows }));
	}
	console.log(`${rows.length}/4 ${row.id}; text calls ${freshTextCalls}; cumulative Jev $${budget.snapshot.knownUsd.toFixed(6)}`);
}

const ratio = (numerator, denominator) => denominator === 0 ? null : numerator / denominator;
const policies = ["first/raw", "best-support/raw", "best-support@0.5", "best-support@0.7", "best-support@0.8", "best-support@0.7+route@0.5"].flatMap((name) => [name, `${name}+closed`]);
function summarize(selectedRows, policy) {
	let gold = 0, joint = 0, grouping = 0, answered = 0, fullBase = 0, fullPass = 0, completed = 0, serviceFailures = 0, notRun = 0, changingOutputs = 0, changingMembership = 0, semanticPassFlips = 0, contractPass = 0;
	const wallMs = [], modeledMs = [];
	for (const row of selectedRows) {
		const labCase = cases.find((item) => item.id === row.id);
		const known = { units: labCase.idealOutput.units.filter(({ route }) => route !== "Unresolved" && route.family !== "Foreign") };
		const outputs = new Set(), membership = new Set(), passes = new Set();
		for (const rep of row.repetitions) {
			gold += known.units.length;
			if (labCase.facts.coverage === "Full") fullBase++;
			const output = rep.result?.outputs?.[policy] ?? (rep.result?.primary === "fallback" ? rep.result.outputs.fallback : undefined);
			if (!output) { if (rep.notRun) notRun++; else serviceFailures++; continue; }
			completed++;
			const source = { input: labCase.input, spans: sourceSpans(labCase.input.segments), unresolved: [] };
			const counts = evaluateSourceAndUnits(labCase.input, known, source, output).units;
			const all = evaluateSourceAndUnits(labCase.input, labCase.idealOutput, source, output, labCase.facts.coverage).units;
			joint += counts.routeMatches;
			grouping += counts.groupingMatches;
			contractPass += Number(all.contractPass);
			fullPass += Number(all.fullPass);
			for (const unit of known.units) {
				const touching = output.units.filter((candidate) => candidate.segments.some((segment) => unit.segments.includes(segment)));
				if (touching.length > 0 && touching.every(({ route }) => route !== "Unresolved")) answered++;
			}
			outputs.add(JSON.stringify(output));
			membership.add(JSON.stringify(output.units.map(({ segments }) => segments)));
			passes.add(counts.routeMatches === counts.gold);
			wallMs.push(rep.wallMs);
			modeledMs.push(modeledLatency(rep.calls));
		}
		changingOutputs += Number(outputs.size > 1);
		changingMembership += Number(membership.size > 1);
		semanticPassFlips += Number(passes.size > 1);
	}
	return { policy, scheduledRepetitions: selectedRows.length * 3, completed, serviceFailures, notRun, goldUnitRepetitions: gold, groupingMatches: grouping, jointMatches: joint, groupingAccuracy: ratio(grouping, gold), jointAccuracy: ratio(joint, gold), answeredGoldUnitCoverage: ratio(answered, gold), answeredGoldUnits: answered, jointAccuracyAmongAnswered: ratio(joint, answered), fullPass, fullBase, fullPassRate: ratio(fullPass, fullBase), contractPass, completedCasesWithOutputVariation: changingOutputs, completedCasesWithMembershipVariation: changingMembership, semanticPassFlips, wallMs, modeledMs };
}
const summary = { smokeOnly: true, ids, repetitions: 3, freshTextCalls, freshJevCalls, budget: budget.snapshot, textCostUsd: null, textUsage: exchanges.filter((exchange) => exchange.usage).map(({ actualModel, actualTier, usage, latencyMs }) => ({ actualModel, actualTier, usage, latencyMs })), policies: policies.map((policy) => summarize(rows, policy)), comparisons: { baseline: summarize(references.baseline.rows, references.baseline.policy), ownership: ["raw+closed", "support@0.7+closed"].map((policy) => summarize(references.ownership.rows, policy)), envelopes: ["raw+closed", "support@0.7+closed"].map((policy) => summarize(references.envelopes.rows, policy)) } };
await writeFile(join(outputDirectory, "summary.json"), JSON.stringify(summary, null, 2));
console.log(JSON.stringify({ outputDirectory, freshTextCalls, textCostUsd: null, budget: budget.snapshot, bestRaw: summary.policies.find(({ policy }) => policy === "best-support/raw+closed"), primary: summary.policies.find(({ policy }) => policy === "best-support@0.7+closed"), baseline: summary.comparisons.baseline }));
