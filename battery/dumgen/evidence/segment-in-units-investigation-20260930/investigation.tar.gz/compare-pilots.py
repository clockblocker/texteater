"""Read-only rescore of immutable pilot artifacts; never calls a provider."""
import json
from pathlib import Path

ROOT = Path('/private/tmp/segment-in-units-investigation-20260930')
REPO = Path('/Users/annagorelova/work/textfresser-batteries')
GOLD = json.loads((REPO / 'battery/dumgen/.runs/segment-in-units-lab/sets/dev.json').read_text())
BY_GOLD = {row['id']: row for row in GOLD['cases']}
MANIFEST = json.loads((ROOT / 'pilot32.json').read_text())
BASELINE = json.loads((REPO / 'battery/dumgen/.runs/segment-in-units-lab/runs/20260929T074903--candidates2--routes-question_tests-1_gen-3--dev--all.json').read_text())
RUNS = [
    ('owner-initial-coverage-limited', 'ownership-2026-09-30T05-12-19.461Z'),
    ('owner-corrected-reference', 'ownership-2026-09-30T05-16-23.759Z'),
    ('envelopes-reference', 'envelopes-2026-09-30T05-25-47.499Z'),
]

def spans(segments):
    end = 0
    result = []
    for segment in segments:
        start, end = end, end + len(segment['text'].encode('utf-16-le')) // 2
        result.append((start, end))
    return result

def effective_assertions(gold, source):
    predicted = source['input']['segments']
    by_span = dict(zip(spans(predicted), predicted))
    for segment, span in zip(gold['input']['segments'], spans(gold['input']['segments'])):
        if 'surface' not in segment:
            continue
        actual = by_span.get(span)
        if not actual or actual['kind'] != segment['kind'] or actual['text'] != segment['text']:
            return False
        if segment['surface'] != actual.get('surface', actual['text']):
            return False
    return ''.join(x['text'] for x in predicted) == ''.join(x['text'] for x in gold['input']['segments'])

def extra_counts(rows, selected, policy):
    all_gold = stubs = stub_grouping = stub_routes = passed = flips = 0
    source_effective = output_changes = member_changes = output_base = completed_flips = errors = 0
    for row in rows:
        if row['id'] not in selected:
            continue
        passes = set()
        completed_passes, outputs, memberships = set(), set(), set()
        complete = 0
        for rep in row['repetitions']:
            if 'evaluations' not in rep:
                gold_units = BY_GOLD[row['id']]['idealOutput']['units']
                all_gold += len(gold_units)
                stubs += sum(unit['route'] == 'Unresolved' or unit['route']['family'] == 'Foreign' for unit in gold_units)
                passes.add(False)
                errors += 1
                continue
            ev = rep['evaluations'][policy]
            known, all_units = ev['known']['units'], ev['all']['units']
            all_gold += all_units['gold']
            stubs += all_units['gold'] - known['gold']
            stub_grouping += all_units['groupingMatches'] - known['groupingMatches']
            stub_routes += all_units['routeMatches'] - known['routeMatches']
            ok = known['gold'] > 0 and known['routeMatches'] == known['gold']
            passed += ok
            passes.add(ok)
            completed_passes.add(ok)
            complete += 1
            output = rep['result']['outputs'][policy]
            outputs.add(json.dumps(dict(source=rep['source']['input'], units=output['units']), sort_keys=True))
            memberships.add(json.dumps(dict(source=rep['source']['spans'], kinds=[x['kind'] for x in rep['source']['input']['segments']],
                                            units=[x['segments'] for x in output['units']]), sort_keys=True))
            source_effective += effective_assertions(BY_GOLD[row['id']], rep['source'])
        flips += len(passes) > 1
        output_base += complete >= 2
        output_changes += len(outputs) > 1
        member_changes += len(memberships) > 1
        completed_flips += len(completed_passes) > 1
    return dict(allGoldUnitRepetitions=all_gold, goldStubUnitRepetitions=stubs,
                stubGroupingMatches=stub_grouping, stubRouteMatches=stub_routes,
                knownUnitCasePass=passed, knownUnitPassFailFlips=flips,
                sourceEffectiveAnnotatedRecoveryExact=source_effective,
                completedOnlyOutputVariation=output_changes, completedOnlyMembershipVariation=member_changes,
                completedOnlyVariationBase=output_base, completedOnlyKnownUnitPassFailFlips=completed_flips,
                serviceCompletedAttempts=sum(len(row['repetitions']) for row in rows if row['id'] in selected) - errors)

def baseline_counts(selected, policy):
    all_gold = stubs = stub_grouping = stub_routes = passed = flips = 0
    for row in BASELINE['cases']:
        if row['id'] not in selected:
            continue
        gold = BY_GOLD[row['id']]['idealOutput']['units']
        known = [x for x in gold if x['route'] != 'Unresolved' and x['route']['family'] != 'Foreign']
        stub = [x for x in gold if x not in known]
        passes = set()
        for rep in row['repetitions'][:3]:
            units = rep['outputs'][policy]['units']
            def exact(unit):
                return [x for x in units if sorted(x['segments']) == sorted(unit['segments'])]
            ok = len(known) > 0 and all(any(x['route'] == unit['route'] for x in exact(unit)) for unit in known)
            passed += ok
            passes.add(ok)
            all_gold += len(gold)
            stubs += len(stub)
            stub_grouping += sum(bool(exact(unit)) for unit in stub)
            stub_routes += sum(any(x['route'] == unit['route'] for x in exact(unit)) for unit in stub)
        flips += len(passes) > 1
    return dict(allGoldUnitRepetitions=all_gold, goldStubUnitRepetitions=stubs,
                stubGroupingMatches=stub_grouping, stubRouteMatches=stub_routes,
                knownUnitCasePass=passed, knownUnitPassFailFlips=flips,
                serviceCompletedAttempts=3 * len(selected))

columns = ['cases', 'repetitions', 'goldUnitRepetitions', 'groupingAccuracy', 'jointRouteAccuracy',
           'answeredGoldUnitCoverage', 'jointAccuracyAmongAnsweredGoldUnits', 'exactOutputChanges',
           'exactMembershipChanges', 'contractPass', 'fullPass', 'fullBase',
           'sourceBoundaryExact', 'sourceAnnotatedRecoveryExact', 'inputTokensPerSentenceRepetition',
           'freshCalls', 'cachedCalls', 'modeledLatencyMs', 'wallLatencyMs', 'errors']
table = []
provenance = []
for label, run_id in RUNS:
    path = ROOT / run_id
    summary = json.loads((path / 'summary.json').read_text())
    run = json.loads((path / 'run.json').read_text())
    provenance.append(dict(label=label, runId=run_id, immutableSummary=str(path / 'summary.json'),
                           sourceHash=summary['configuration'].get('sourceHash'),
                           budget=summary['budget'], actualModels=summary['actualModels']))
    for scope in ['representative', 'challenge']:
        selected = set(MANIFEST[scope])
        metrics = summary['metrics'][scope]
        if label == RUNS[0][0]:
            metric = metrics['baseline']
            table.append(dict(scope=scope, architecture='recorded-v3-candidates', input='gold',
                              policy=metric['policy'], **{key: metric[key] for key in columns},
                              **baseline_counts(selected, metric['policy'])))
        for mode in ['gold', 'source']:
            rows = [row for row in run['rows'] if row['mode'] == mode]
            for metric in metrics['owner'][mode]:
                if metric['policy'] not in ['raw+closed', 'endpoints+closed', 'support@0.7+closed']:
                    continue
                table.append(dict(scope=scope, architecture=label, input=mode, policy=metric['policy'],
                                  **{key: metric[key] for key in columns},
                                  **extra_counts(rows, selected, metric['policy'])))

result = dict(
    scope='16 deterministic source-hash dev cases and 16 intentional baseline failures, separately; repeated outputs are measurements, not production retries',
    goldHash=GOLD['hash'], ids=MANIFEST['ids'], runs=provenance, table=table,
    definitions=dict(
        jointRouteAccuracy='Exact source-span/render-kind membership plus language/family/kind over all annotated known gold unit repetitions; wrong groups and abstentions stay in denominator',
        answeredGoldUnitCoverage='Gold known units touched by at least one predicted unit, with every touching prediction routed rather than Unresolved; may include wrong groups',
        knownUnitCasePass='Every explicitly annotated known gold unit matches membership and route, without claims about unannotated units or Full extra checks',
        knownUnitPassFailFlips='Cases whose knownUnitCasePass boolean varies across three repetitions; separate from exact output variation',
        contractPass='Structural ownership partition only, not semantic correctness',
        sourceAnnotatedRecoveryExact='Immutable original helper score compared explicit surface-field presence; redundant identity copy may fail',
        sourceEffectiveAnnotatedRecoveryExact='Offline semantic correction: an explicit gold surface equals actual.surface or actual.text; does not rewrite original artifacts',
        wallLatencyMs='Includes cache reuse; source gold-equivalent calls share cache and observed wall time is not inference latency',
        completedOnlyOutputVariation='Cases with different complete output values among at least two successful attempts; excludes transport failures as output values',
        baseline='Pre-existing v3 outputs never refetched; gold Segments/recovered surfaces; model alias was jev-latest',
    ),
)
(ROOT / 'pilot-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
for row in table:
    print(row['scope'], row['architecture'], row['input'], row['policy'],
          'group', round(100 * row['groupingAccuracy'], 2), 'joint', round(100 * row['jointRouteAccuracy'], 2),
          'outputVariations', row['exactOutputChanges'], 'passFailFlips', row.get('knownUnitPassFailFlips'))
