/** Offline candidate recall; no inference and no writes to existing run evidence. */
import { readFile, writeFile } from "node:fs/promises";
import { evaluateSourceAndUnits } from "/Users/annagorelova/work/textfresser-batteries/battery/dumgen/src/segment-in-units/de/source-evaluation.ts";
const root = "/private/tmp/segment-in-units-investigation-20260930";
const runId = Bun.argv[2];
if (!runId) throw Error("A completed run id is required");
const run = JSON.parse(await readFile(`${root}/${runId}/run.json`, "utf8"));
const manifest = JSON.parse(await readFile(`${root}/pilot32.json`, "utf8"));
const gold = JSON.parse(await readFile("/Users/annagorelova/work/textfresser-batteries/battery/dumgen/.runs/segment-in-units-lab/sets/dev.json", "utf8"));
const byGold = new Map(gold.cases.map((row) => [row.id, row]));
const rows = [];
for (const row of run.rows) {
	const reference = byGold.get(row.id);
	for (const [repetition, rep] of row.repetitions.entries()) {
		if (!rep.result || !rep.source) { rows.push({id:row.id,mode:row.mode,repetition,error:rep.error});continue; }
		const mapping = evaluateSourceAndUnits(reference.input, reference.idealOutput, rep.source, {units:[]}).segmentMapping;
		const sourcePieces = rep.source.input.segments.flatMap(({kind},index) => kind === "ResolvableText" ? [index] : []);
		const pieceToGold = new Map(sourcePieces.map((segment,index) => [index+1,mapping[segment]]));
		const goldToPiece = new Map(sourcePieces.flatMap((segment,index) => mapping[segment] === null ? [] : [[mapping[segment],index+1]]));
		for (const unit of reference.idealOutput.units) {
			if (unit.route === "Unresolved" || unit.route.family === "Foreign") continue;
			const firstGold = Math.min(...unit.segments), lastGold = Math.max(...unit.segments);
			const first = goldToPiece.get(firstGold), last = goldToPiece.get(lastGold);
			const exactSourceMembers = unit.segments.every((segment) => goldToPiece.has(segment));
			const sourceResolved = exactSourceMembers && unit.segments.every((segment) => !rep.source.unresolved.includes(sourcePieces[goldToPiece.get(segment)-1]));
			const hypothesis = rep.result.boundaries.find((boundary) => boundary.piece === first);
			const matchingEnvelope = rep.result.envelopes.find((envelope) => envelope.first === first && envelope.last === last);
			const predicted = rep.result.masks.find((mask) => matchingEnvelope && mask.owner === matchingEnvelope.key);
			const assignedGoldMembers = predicted?.group.map((piece) => pieceToGold.get(piece));
			const exactMatchingEnvelopeMask = assignedGoldMembers?.length === unit.segments.length && assignedGoldMembers.every((member) => unit.segments.includes(member));
			const exactMask = rep.result.masks.some((mask) => mask.group.length === unit.segments.length && mask.group.every((piece) => unit.segments.includes(pieceToGold.get(piece))));
			rows.push({ id:row.id,mode:row.mode,repetition,family:unit.route.family,kind:unit.route.kind,
				goldMembers:unit.segments,multi:unit.segments.length>1,first,last,exactSourceMembers,sourceResolved,
				firstProbability:hypothesis?.probability,lastShare:hypothesis?.share,
				conditionalLastCorrect:hypothesis?.last === last && first !== undefined && last !== undefined,
				firstAccepted:hypothesis?.probability>=.5,
				candidateAvailable:unit.segments.length===1 ? sourceResolved : sourceResolved && matchingEnvelope!==undefined,
				exactMask,
				exactMatchingEnvelopeMask: unit.segments.length === 1 ? exactMask : Boolean(exactMatchingEnvelopeMask),
			});
		}
	}
}
const count = (selected) => ({goldUnitRepetitions:selected.length,
	exactSourceMembers:selected.filter((row) => row.exactSourceMembers).length,
	sourceResolved:selected.filter((row) => row.sourceResolved).length,
	conditionalLastCorrect:selected.filter((row) => row.conditionalLastCorrect).length,
	firstAccepted:selected.filter((row) => row.firstAccepted).length,
	candidateAvailable:selected.filter((row) => row.candidateAvailable).length,
	exactMask:selected.filter((row) => row.exactMask).length,
	exactMatchingEnvelopeMask:selected.filter((row) => row.exactMatchingEnvelopeMask).length,
	exactMaskAmongAvailable:selected.filter((row) => row.candidateAvailable && row.exactMask).length});
const metrics = {};
for (const scope of ["representative","challenge"]) {
	metrics[scope] = {};
	for (const mode of ["gold","source"]) {
		const selected = rows.filter((row) => manifest[scope].includes(row.id) && row.mode===mode && !row.error);
		metrics[scope][mode] = {all:count(selected),multi:count(selected.filter((row) => row.multi)),single:count(selected.filter((row) => !row.multi))};
	}
}
await writeFile(`${root}/${runId}-candidate-coverage.json`,JSON.stringify({runId,goldHash:gold.hash,metrics,rows},null,2)+"\n");
console.log(JSON.stringify(metrics,null,2));
